export const GET_USERS = "GET_USERS";
export const DELETE_USERS = "DELETE_USERS";
export const ADD_USERS = "ADD_USERS";
export const GET_SINGLE_USER = "GET_SINGLE_USER";
export const UPDATE_USER = "UPDATE_USER";
