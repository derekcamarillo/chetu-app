import React,{ useEffect, useState } from 'react'
import "./index.css"
import axios from 'axios';

const Index = ()=>{
    const url = `https://data.covid19india.org/v4/min/timeseries.min.json`;
    // const [email] = useState("");
    const [data, setData] = useState([])

  
    useEffect(() => {
      axios.get(url).then(json => setData(json.data))
      // eslint-disable-next-line
    }, [])
    console.log(data.tested)
    
    function handle(e){
        const newdata = {...data}
        newdata[e.target.id] = e.target.value
        setData(newdata)
        console.log(newdata)
      }


    return (
        <div className="home">
            <div className="main">
                <div className="card1">
                    Hello
                </div>
                <div className="card2">
                    Hello2
                    <input type="submit" onClick={(e) => handle(e)} value="submit" />
                </div>
                <div className="card3">
                    Hello3
                </div>
            </div>
        </div>
    )
}

export default Index
