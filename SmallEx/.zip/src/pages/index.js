import React from 'react';
import Card from '../Cards/Cards.jsx';

const Home = () => {
return (
	<>
	<div>
		<h1 className='h1'>Welcome to My First Nevbar page</h1>
	</div>
	<div>
		<Card />
	</div>
	
	</>
);
};

export default Home;
