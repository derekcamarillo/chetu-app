import React from 'react'

const Update = () => {
    return (
        <div>
            <h1>hELLO I am update</h1>
            <h1>hELLO I am update</h1>
        </div>
    )
}

export default Update
