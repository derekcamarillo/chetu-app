import React from 'react';

const Teams = () => {
return (
	<div>
	<h1>Welcome to My Team</h1>
	</div>
);
};

export default Teams;
