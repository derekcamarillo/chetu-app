import React from "react";

export const AboutUs = () => {
return (
	<div className="home">
	<h1>About us</h1>
	</div>
);
};

export const OurAim = () => {
return (
	<div className="home">
	<h1>Our Aim</h1>
	</div>
);
};

export const OurVision = () => {
return (
	<div className="home">
	<h1>Our Vision</h1>
	</div>
);
};
